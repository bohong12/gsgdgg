# 7 Tools Spam Sms

![IMG_20200313_140123](https://user-images.githubusercontent.com/Screenshot_20200329_192537.jpg)

```

Indonesia :

Kode Ini Di Buat Untuk Menjahili Teman Kalian Yang Sedang Asik Mabar 🤣

```

```

Inggris : 

This Code Is Made To Judge Your Friends Who Are Playing The Game 🤣

```

# Installation ( Penginstalan )

```

Termux :

$ pkg install git

$ pkg install python2

$ pip2 install requests

$ pip2 install mechanize

$ git clone https://github.com/Sabila152/SpamSms

$ cd SpamSms

$ python2 Spam.py

Kali Linux :

$ sudo apt-get install git

$ sudo apt install python-pip

$ pip2 install mechanize

$ pip2 install requests

$ git clone https://github.com/Sabila152/SpamSms

$ cd SpamSms

$ python2 Spam.py

```

# Info

```

Creator : ./Sabila

Team : Cyber Girl Indonesian

Youtobe:HackSael

Email : nurvandiasabila@gmail.com

```
